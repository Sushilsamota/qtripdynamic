
const config = { backendEndpoint: "http://65.0.40.89:8082" };

export default config;
